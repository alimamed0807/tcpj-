using System.Net;
using System.Net.Sockets;
using System.Text.Json;

class UserRecord
{
    public string Username { get; set; } = "";
    public string Password { get; set; } = "";
    public string RemoteEndpoint { get; set; } = "";
    public bool IsOnline { get; set; }
}

class ClientSession
{
    public TcpClient Client { get; set; } = null!;
    public StreamWriter Writer { get; set; } = null!;
    public string Username { get; set; } = "";
    public object SendLock { get; } = new object();
}

class Program
{
    static readonly object gate = new object();
    static readonly List<UserRecord> users = new List<UserRecord>();
    static readonly List<ClientSession> sessions = new List<ClientSession>();
    static readonly string filePath = Path.Combine(AppContext.BaseDirectory, "users.json");

    static void Main()
    {
        if (!File.Exists(filePath))
        {
            Console.WriteLine("users.json missing.");
            return;
        }

        string json = File.ReadAllText(filePath);
        users.AddRange(JsonSerializer.Deserialize<List<UserRecord>>(json) ?? new List<UserRecord>());

        TcpListener server = new TcpListener(IPAddress.Any, 27001);
        server.Start();

        Console.WriteLine("Server: 27001");
        Console.WriteLine("Stop: Ctrl+C");

        while (true)
        {
            TcpClient client = server.AcceptTcpClient();
            Thread thread = new Thread(() => HandleClient(client));
            thread.Start();
        }
    }

    static void HandleClient(TcpClient client)
    {
        ClientSession? session = null;

        try
        {
            NetworkStream stream = client.GetStream();
            StreamReader reader = new StreamReader(stream);
            StreamWriter writer = new StreamWriter(stream) { AutoFlush = true };

            string ip = ((IPEndPoint)client.Client.RemoteEndPoint!).Address.ToString();
            string? loginLine = reader.ReadLine();

            if (loginLine == null)
                return;

            string[] parts = loginLine.Split('|');
            if (parts.Length != 3 || parts[0] != "LOGIN")
            {
                writer.WriteLine("ERROR|Format sehvdir.");
                return;
            }

            string username = parts[1];
            string password = parts[2];

            lock (gate)
            {
                UserRecord? user = users.FirstOrDefault(u =>
                    u.Username == username && u.Password == password);

                if (user == null)
                {
                    writer.WriteLine("ERROR|Login sehvdir.");
                    return;
                }

                if (user.IsOnline)
                {
                    writer.WriteLine("ERROR|Already online.");
                    return;
                }

                user.IsOnline = true;
                user.RemoteEndpoint = client.Client.RemoteEndPoint!.ToString()!;
                session = new ClientSession
                {
                    Client = client,
                    Writer = writer,
                    Username = username
                };
                sessions.Add(session);
                SaveUsers();
            }

            Console.WriteLine($"[ONLINE] {username} | {client.Client.RemoteEndPoint}");
            writer.WriteLine("OK|Login OK.");

            BroadcastUsers();

            string? command;
            while ((command = reader.ReadLine()) != null)
            {
                if (command.Equals("EXIT", StringComparison.OrdinalIgnoreCase))
                    break;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Client left.");
        }
        finally
        {
            if (session != null)
            {
                lock (gate)
                {
                    sessions.Remove(session);
                    UserRecord? user = users.FirstOrDefault(u => u.Username == session.Username);
                    if (user != null)
                        user.IsOnline = false;
                    SaveUsers();
                }

                Console.WriteLine($"[OFFLINE] {session.Username}");
                BroadcastUsers();
            }

            client.Close();
        }
    }

    static void BroadcastUsers()
    {
        List<UserRecord> snapshot;
        List<ClientSession> connected;

        lock (gate)
        {
            snapshot = users.Select(u => new UserRecord
            {
                Username = u.Username,
                RemoteEndpoint = u.RemoteEndpoint,
                IsOnline = u.IsOnline
            }).ToList();

            connected = sessions.ToList();
        }

        string message = "LIST|" + JsonSerializer.Serialize(snapshot);

        foreach (ClientSession session in connected)
        {
            try
            {
                lock (session.SendLock)
                    session.Writer.WriteLine(message);
            }
            catch
            {
                }
        }

        Console.WriteLine("Users:");
        foreach (UserRecord user in snapshot)
        {
            string status = user.IsOnline ? "ONLINE" : "OFFLINE";
            string ip = string.IsNullOrWhiteSpace(user.RemoteEndpoint) ? "-" : user.RemoteEndpoint;
            Console.WriteLine($"{user.Username,-10} | {ip,-22} | {status}");
        }
        Console.WriteLine();
    }

    static void SaveUsers()
    {
        string json = JsonSerializer.Serialize(users, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(filePath, json);
    }
}
