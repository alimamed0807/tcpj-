using System.Net.Sockets;
using System.Text.Json;

class UserStatus
{
    public string Username { get; set; } = "";
    public string RemoteEndpoint { get; set; } = "";
    public bool IsOnline { get; set; }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("TCP Client");
        Console.Write("Server IP: ");
        string ip = Console.ReadLine() ?? "127.0.0.1";

        Console.Write("Username: ");
        string username = Console.ReadLine() ?? "";

        Console.Write("Password: ");
        string password = Console.ReadLine() ?? "";

        try
        {
            TcpClient client = new TcpClient();
            client.Connect(ip, 27001);

            NetworkStream stream = client.GetStream();
            StreamReader reader = new StreamReader(stream);
            StreamWriter writer = new StreamWriter(stream) { AutoFlush = true };

            writer.WriteLine($"LOGIN|{username}|{password}");

            string? response = reader.ReadLine();
            if (response == null || response.StartsWith("ERROR|"))
            {
                Console.WriteLine(response?.Substring("ERROR|".Length) ?? "Server closed connection.");
                client.Close();
                return;
            }

            Console.WriteLine(response.Substring("OK|".Length));
            Console.WriteLine("Users:");
            Console.WriteLine("Exit: Exit");

            Thread receiveThread = new Thread(() =>
            {
                try
                {
                    string? line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.StartsWith("LIST|"))
                        {
                            string json = line.Substring("LIST|".Length);
                            List<UserStatus> list =
                                JsonSerializer.Deserialize<List<UserStatus>>(json) ?? new List<UserStatus>();

                            Console.WriteLine("\nUsers:");
                            foreach (UserStatus user in list)
                            {
                                string status = user.IsOnline ? "ONLINE" : "OFFLINE";
                                string endpoint = string.IsNullOrWhiteSpace(user.RemoteEndpoint)
                                    ? "-" : user.RemoteEndpoint;
                                Console.WriteLine($"{user.Username,-10} | {endpoint,-22} | {status}");
                            }
                            Console.WriteLine();
                            Console.Write("> ");
                        }
                    }
                }
                catch
                {
                    Console.WriteLine("\nDisconnected.");
                }
            });
            receiveThread.IsBackground = true;
            receiveThread.Start();

            while (true)
            {
                string? command = Console.ReadLine();
                if (command == null || command.Equals("Exit", StringComparison.OrdinalIgnoreCase))
                {
                    writer.WriteLine("EXIT");
                    break;
                }

                Console.WriteLine("Type Exit.");
                Console.Write("> ");
            }

            client.Close();
            Console.WriteLine("Logged out.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
            Console.WriteLine("Check server and IP.");
        }
    }
}
